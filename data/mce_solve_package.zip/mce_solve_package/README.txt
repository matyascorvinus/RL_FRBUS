This distribution contains EViews code for the solution algorithms
presented in "Two Practical Algorithms for Solving Rational
Expectations Models," FEDS 2011-44.  The distribution includes:

1.  The FEDS paper (FEDS_2011-44.pdf)
2.  A users guide (mce_solve_users_guide.pdf)
3.  The EViews code (mce_solve_library.prg)
4.  Five example programs
5.  A guide to the examples (MCE Solve Examples.pdf)  
